import "./Card.css";


type CardProps = {
    value: number;
    isRevealed: boolean;
    isSelected?: boolean;
    onClick?: () => void;
}


export default function Card({ value, isRevealed, isSelected, onClick }: CardProps) {
    return (
        <div 
            className="card" 
            onClick={onClick} 
            style={{
                border: isSelected ? "3px solid dodgerblue" : "1px solid #999", 
                backgroundColor: isSelected ? "#eef6ff" : "white",
        }}>
            {isRevealed ? value : "?"}
        </div>
    )
}