import { useState } from "react";
import Card from "./components/Card";


const debug = 0;

type Player = {
  hand: number[],
  sum: number,
  pile: number[],
  revealIndex: number[]
}


type GamePhase = 
  | "not started"
  | "initial card selection"
  | "turn order decided"
  | "reveal card"
  | "check or trade : choose check or trade"
  | "trade"
  | "trade opponent card"
  | "finished";


export default function App() {
  const [phase, setPhase] = useState<GamePhase>("not started");
  const [currentPlayer, setCurrentPlayer] = useState(0);
  const [cardCount, setCardCount] = useState(0);
  const [players, setPlayers] = useState<Player[]>([
    {
      hand: [],
      sum: 0,
      pile: [1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10],
      revealIndex: []
    },
    {
      hand: [],
      sum: 0,
      pile: [1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10],
      revealIndex: []
    }
  ]);

  //const [chosenCard, setChosenCard] = useState(0);
  const [tradeIndex, setTradeIndex] = useState(0);
  const [countAction, setCountAction] = useState(0);
  const [winner, setWinner] = useState("none");
  const opponent = currentPlayer === 0 ? 1 : 0;
  const viewingPlayer = phase === "trade opponent card" ? opponent : currentPlayer;
  const [selectedIndex, setSelectedIndex] = useState<number | null>(null);
  const [firstPlayer, setFirstPlayer] = useState(0);
  const [revealStep, setRevealStep] = useState(0);
  const [ackPlayer, setAckPlayer] = useState<number | null>(null);

  const showHandoff = 
    phase !== "not started" && 
    phase !== "finished" && 
    ackPlayer !== viewingPlayer;


  function nextPlayer(playerNum: number) {
    if (playerNum === 0) setCurrentPlayer(1);
    else setCurrentPlayer(0);
  }

  function cardSelected(index: number) {
    if (selectedIndex === index) {
      setSelectedIndex(null);
      //setChosenCard(0);
      return;
    }
    setSelectedIndex(index);
    //setChosenCard(players[currentPlayer].pile[index]);
  }

  function checkCard(){ 
    if (phase !== "initial card selection") return;
    if (selectedIndex === null) return;

    const pile = players[currentPlayer].pile;
    const cardValue = pile[selectedIndex];

    // check whether its not gonna exceed 21
    if (players[currentPlayer].sum + cardValue > 21) {
      return;
    }

    const newPile = [...pile];
    newPile.splice(selectedIndex, 1);
  
    setPlayers(
      players.map((player, index) => {
        if (index === currentPlayer) {
          const newPlayer = {
            hand: [...player.hand, cardValue],
            sum: player.sum + cardValue,
            pile: newPile,
            revealIndex: []
          };
          return newPlayer;
        } else {
          return player;
        }
      })
    );
    const newCardCount=cardCount+1;
    setCardCount(newCardCount);
    // 選択状態Reset
    setSelectedIndex(null);
    //setChosenCard(0);

    if (newCardCount === 4) {
      setCardCount(0);

      // proceed to 2nd player
      if (currentPlayer === 0) {
        nextPlayer(currentPlayer);
      }
      // proceed to next phase
      if (currentPlayer === 1) {
        // randomly decide who starts
        const playOrder = Math.floor(Math.random() * 2);
        setFirstPlayer(playOrder);
        setCurrentPlayer(playOrder);
        setRevealStep(0);
        setPhase("turn order decided");
      }
    }
  }

  function startGame() {
    setCurrentPlayer(0);
    setCardCount(0);

    setPhase("initial card selection");
  }

  function chooseCard(num: number) {
    // 手番の相手のplayer
    const opponent = currentPlayer === 0 ? 1 : 0;

    setPlayers(
      players.map((player, index) => {
        if (index === opponent) {
          return {
            ...player,
            revealIndex: [...player.revealIndex, num-1]
          };
        }
        return player;
      })
    );
    if (revealStep === 0) {
      // 一人目の公開が終了
      setRevealStep(1);
      setCurrentPlayer(opponent);
    } else {
      // 二人目の公開も終了したので先攻からCheck/Tradeへ
      setCurrentPlayer(firstPlayer);
      setPhase("check or trade : choose check or trade");
    }
  }

  function check() {
    const newCountAction = countAction+1;
    setCountAction(newCountAction);
    decideNextAction(newCountAction, players);
  }

  function trade() {
    // the player can choose which one to exchange
    setPhase("trade");
    return;
  }

  function tradeCard(num: number) {
    setTradeIndex(num);
    setPhase("trade opponent card");
  }

  function tradeOpponentCard(num: number) {
    const opponent = currentPlayer === 0 ? 1 : 0;
    const myIndex = tradeIndex - 1 ;
    const opponentIndex = num - 1;
    let myCard = players[currentPlayer].hand[myIndex];
    let opponentCard = players[opponent].hand[opponentIndex];
    // そのカードが交換前に公開されていたか
    const isMyCardRevealed = players[currentPlayer].revealIndex.includes(myIndex);
    const isOpponentCardRevealed = players[opponent].revealIndex.includes(opponentIndex);

    // ここでなくなったCardを削除してTradeされたCardはRevealに入れる
    const newPlayers = players.map((player, index) => {
        if (index === currentPlayer) {
          const newHand = [...player.hand]
          newHand[tradeIndex-1] = opponentCard;

          // 自分が出したCardのIndexは一旦Revealから外す
          let newRevealIndex = player.revealIndex.filter(i => i !== myIndex);
          // 相手から来たCardが公開済みならそれをRevealとして挿入する
          if (isOpponentCardRevealed) {
            newRevealIndex = [...newRevealIndex, myIndex];
          }
          
          return { ...player, hand: newHand, sum: player.sum - myCard + opponentCard, revealIndex: newRevealIndex };
        } 
        if (index === opponent) {
          const newHand = [...player.hand]
          newHand[num-1] = myCard;

          let newRevealIndex = player.revealIndex.filter(i => i !== opponentIndex);
          if (isMyCardRevealed) {
            newRevealIndex = [...newRevealIndex, opponentIndex];
          }

          return { ...player, hand: newHand, sum: player.sum - opponentCard + myCard, revealIndex: newRevealIndex};
        }
        return player;
      });
    setPlayers(newPlayers);
    const newCountAction = countAction + 1;
    setCountAction(newCountAction);
    decideNextAction(newCountAction, newPlayers);
  }

  function decideNextAction(count: number, players: Player[]) {
    if (count === 1) {
      nextPlayer(currentPlayer);
      setPhase("check or trade : choose check or trade");
    }
    if (count === 2) {
      const result = judgement(players);
      setWinner(result);
      setPhase("finished");
    }
  }


  function judgement(players: Player[]) {
    // closer to 21 will win (more than 21 will be lose)
    const player0 = players[0].sum;
    const player1 = players[1].sum;
    
    const isOut0 = player0 > 21;
    const isOut1 = player1 > 21;

    if (isOut0 && isOut1) return "draw";
    if (isOut0) return "player1";
    if (isOut1) return "player0";

    if (player0 > player1) return "player0";
    if (player1 > player0) return "player1";

    return "draw";
  }


  function resetSelection() {
    setPlayers(
      players.map((player, index) => {
        if (index === currentPlayer) {
          return {
            ...player,
            hand: [],
            sum: 0,
            pile: [...player.hand, ...player.pile].sort((a, b) => a - b),
            revealIndex: []
          };
        }
        return player;
      })
    );
    setCardCount(0);
    setSelectedIndex(null);
  }






  return(
    <>
      {showHandoff && (
        <div 
          style={{
            position: "fixed",
            inset: 0,
            backgroundColor: "black",
            color: "white",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            gap: "16px",
            textAlign: "center",
            padding: "24px",
            zIndex: 1000,
          }}
        >

          <p style={{ fontSize: "1.5rem" }}>
            It's Player {viewingPlayer+1}'s turn
          </p>
          <button
            onClick={() => setAckPlayer(viewingPlayer)}
            style={{ fontSize: "1.2rem", padding: "10px 24px" }}
          >
            Player {viewingPlayer+1}
          </button>
        </div>
      )}

      {debug === 1 && (
        <>
          <p>Current Player: {currentPlayer+1}</p>
          <p>Game Status: {phase}</p>
          <br/>
        </>
      )}

      <p>
        Player 1 hand: 
      </p>
      <div style={{ display: "flex", gap: "8px", alignItems: "center" }}>
        {players[0].hand.map((cardValue, i) => 
          <Card key={i} value={cardValue} isRevealed={players[0].revealIndex.includes(i) || viewingPlayer === 0 || phase === "finished"}/>
        )}
      </div>
      {(currentPlayer === 0 || phase === "finished") && (
        <>
        <p>(full hand: {players[0].hand.join(", ")})</p>
          <p>Player 1 sum: {players[0].sum}</p><br/>
        </>
      )}
      <br/>

      <p>
        Player 2 hand: 
      </p>
      <div style={{ display: "flex", gap: "8px", alignItems: "center" }}>
        {players[1].hand.map((cardValue, i) => 
          <Card key={i} value={cardValue} isRevealed={players[1].revealIndex.includes(i) || viewingPlayer === 1 || phase === "finished"}/>
        )}
      </div>
      {(currentPlayer === 1 || phase === "finished") && (
        <>
          <p>(full hand: {players[1].hand.join(", ")})</p>
          <p>Player 2 sum: {players[1].sum}</p><br/>
        </>
      )}

      {phase === "not started" && (
        <><br/>
          <button onClick={startGame}>Start Game</button><br/>
        </>
      )}

      {/* カード選択 */}
      {phase === "initial card selection" && (
        <><br/>
          <p>
            Player {currentPlayer+1}: choose a card from 1~10 (remain: {21 - players[currentPlayer].sum})
          </p>

          <div style={{display: "flex", gap: "8px", alignItems: "center"}}>
            {players[currentPlayer].pile.map((cardValue, i) => 
              <Card key={i} value={cardValue} isRevealed={true} isSelected={selectedIndex === i} onClick={() => cardSelected(i)}/>
            )}
          </div>

          <button type="submit" onClick={checkCard} disabled={selectedIndex === null}>Confirm</button>
          <button type="reset" onClick={resetSelection}>Reset</button>
        </>
      )}

      {phase === "turn order decided" && (
        <>
          <p>先手は Player {currentPlayer+1} です！</p>
          <button onClick={() => setPhase("reveal card")}>Start Revealing</button>
        </>
      )}
      
      {phase === "reveal card" && (
        <>
          <p>
            Player {currentPlayer+1}: choose a card
            from Player {currentPlayer === 0 ? 2 : 1}
          </p>

          <div style={{display: "flex", gap: "8px"}}>
            {players[currentPlayer === 0 ? 1 : 0].hand.map((cardValue, i) => 
              <Card key={i} value={cardValue} isRevealed={players[currentPlayer === 0 ? 1 : 0].revealIndex.includes(i)} isSelected={selectedIndex === i} onClick={() => cardSelected(i)}/>
            )}
          </div>

          <button
            onClick={() => {
              if (selectedIndex === null) return;
              chooseCard(selectedIndex + 1);
              setSelectedIndex(null); // 選択状態リセット
            }}
            disabled={selectedIndex === null}
          >
            Confirm
          </button>

          {/*<button onClick={() => chooseCard(1)}>1</button>
          <button onClick={() => chooseCard(2)}>2</button>
          <button onClick={() => chooseCard(3)}>3</button>
          <button onClick={() => chooseCard(4)}>4</button>*/}
        </>
      )}

      {phase === "check or trade : choose check or trade" && (
        <>
          <p>
            Player {currentPlayer+1}: choose either check or trade
          </p>

          <button onClick={check}>check</button>
          <button onClick={trade}>trade</button>
        </>
      )}

      {phase === "trade" && (
        <>
          <p>
            Player {currentPlayer+1}: choose a card to trade
          </p>

          <button onClick={() => tradeCard(1)}>1</button>
          <button onClick={() => tradeCard(2)}>2</button>
          <button onClick={() => tradeCard(3)}>3</button>
          <button onClick={() => tradeCard(4)}>4</button>
        </>
      )}

      {phase === "trade opponent card" && (
        <>
          <p>
            Player {currentPlayer ? 1 : 2}: choose a card to trade 
          </p>

          <button onClick={() => tradeOpponentCard(1)}>1</button>
          <button onClick={() => tradeOpponentCard(2)}>2</button>
          <button onClick={() => tradeOpponentCard(3)}>3</button>
          <button onClick={() => tradeOpponentCard(4)}>4</button>
        </>
      )}

      {phase === "finished" && (
        <>
          <p>
            {winner === "draw"
              ? "Draw!"
              : winner === "player0"
              ? "Player 1 wins!"
              : "Player 2 wins!"}
          </p>
        </>
      )}
    </>
  );
}